import java.util.Date;
/**
 * 测试类
 *
 * @author mg
 * @since 2019-02-02
 */
@Data
public class TestDTO implements Serializable {
	private String name;
}